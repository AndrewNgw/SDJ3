package common;

import model.Product;

public interface IStation3
{
   void registerProduct(Product product);
}
