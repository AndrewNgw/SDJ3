package server_application;

import java.rmi.Remote;
import java.rmi.RemoteException;

import model.Product;

public interface IServer3 extends Remote
{
   void productShipment(Product product) throws RemoteException;
}
