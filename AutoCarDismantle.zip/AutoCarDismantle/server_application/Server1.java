package server_application;

import java.rmi.Naming;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

import model.Car;


public class Server1 implements IServer1
{
private IDAO_Car DB;
   
   public Server1() throws RemoteException {
      UnicastRemoteObject.exportObject( this, 0);
      DB = new DAO_Car();
}
   @Override
   public void registerCar(Car car) throws RemoteException
   {
      // TODO Auto-generated method stub
      DB.addCar(car);
   }
 
   public static void main(String[] args) {
      try { 
         LocateRegistry.createRegistry(1099);
         Server1 server = new Server1();
         Naming.rebind("Station1", server);
         System.out.println("Server1 running..");         
      }
      catch (Exception e) {
         e.printStackTrace();
      }
   }
 
}