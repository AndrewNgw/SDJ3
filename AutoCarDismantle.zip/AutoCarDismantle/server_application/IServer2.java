package server_application;

import java.rmi.Remote;
import java.rmi.RemoteException;

import model.Pallet;

public interface IServer2  extends Remote
{
   void registerPallet(Pallet pallet)throws RemoteException;
}
