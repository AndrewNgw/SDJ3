package server_application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.Pallet;

public class DAO_Pallet implements IDAO_Pallet
{
   
   private final static String userName = "sdjUser";
   private final static String password = "dwh";
   private final static String connectString = "jdbc:msql://localhost:3306/SDJ3";
   
   private Connection connection;
   private PreparedStatement pStatement;
   private String sql;
   
   public DAO_Pallet() {
      try {
         DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
      } catch (SQLException e) {
         System.out.println("Could not load drivers");
         e.printStackTrace();
      }
   }
   

   
   private void openConnection()
   {
      try {
         connection = DriverManager.getConnection(connectString, userName, password);
         System.out.println("Database connection opened");
         connection.setAutoCommit(false);
      } catch (SQLException e) {
         System.out.println("Error Openning conection");
         e.printStackTrace();
      }
   }
   
   private void closeConnection()
   {
      try {
         connection.close();
         System.out.println("Database connection closed");
      } catch (SQLException e) {
         System.out.println("Error closing connection");
         e.printStackTrace();
      }
   }
   
   private void prepareStatementForInsertIntoTable()
   {
      sql = "INSERT INTO CAR ( PALLETID,TYPEOFPART,MAXCAPACITY)"
                  + " VALUES (?, ?, ?)";
      try {
         pStatement = connection.prepareStatement(sql);
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }
   
   private void Insert(int palletId, String typeOfPart, double maxCapacity)
   {
      try {
         pStatement.setInt(1, palletId);
         pStatement.setString(2, typeOfPart);
         pStatement.setDouble(3,maxCapacity);
         
         
         
         pStatement.executeUpdate();      
         
      } catch (SQLException e) {
         if (e.getErrorCode() == 23505) {
            System.out.println("Error: primary key contraint violated");
         } else {
            System.out.println("Error inserting data");
            System.out.println(e);
         }
      } 
   }
   
   private void commit()
   {
      try {
         connection.commit();
      } catch (SQLException e) {
         System.out.println("Error commiting changes");
         e.printStackTrace();
      }
   }

   @Override
   public void addPallet(Pallet pallet)
   {
      // TODO Auto-generated method stub
      openConnection();
      prepareStatementForInsertIntoTable();
      
      Insert(pallet.getPalletId(),pallet.getTypeOfPart(),pallet.getMaxWeightCapacity());
      
      commit();
      closeConnection();
   
      
   }

}
