package server_application;

import java.rmi.Naming;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

import model.Pallet;


public class Server2 implements IServer2
{
private IDAO_Pallet DB;
   
   public Server2() throws RemoteException {
      UnicastRemoteObject.exportObject(this, 0);
      DB = new DAO_Pallet();
}

   @Override
   public void registerPallet(Pallet pallet) throws RemoteException
   {
      // TODO Auto-generated method stub
      DB.addPallet(pallet);
   }
   public static void main(String[] args) {
      try { 
         LocateRegistry.createRegistry(1099);
         Server2 server = new Server2();
         Naming.rebind("Station2", (Remote) server);
         System.out.println("Server2 running..");         
      }
      catch (Exception e) {
         e.printStackTrace();
      }
   }   
}
