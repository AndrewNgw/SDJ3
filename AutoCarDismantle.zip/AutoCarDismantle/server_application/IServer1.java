package server_application;

import java.rmi.Remote;
import java.rmi.RemoteException;

import model.Car;

public interface IServer1 extends Remote
{
   void registerCar(Car car) throws RemoteException;
}
