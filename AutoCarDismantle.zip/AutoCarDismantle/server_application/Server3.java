package server_application;

import java.rmi.Naming;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

import model.Product;

public class Server3 implements IServer3
{
private IDAO_Product DB;
   
   public Server3() throws RemoteException {
      UnicastRemoteObject.exportObject(this, 0);
      DB = new DAO_Product();
}

   @Override
   public void productShipment(Product product) throws RemoteException
   {
      // TODO Auto-generated method stub
      DB.addProduct(product);
   }
   
   public static void main(String[] args) {
      try { 
         LocateRegistry.createRegistry(1099);
         Server3 server = new Server3();
         Naming.rebind("Station3", (Remote) server);
         System.out.println("Server3 running..");         
      }
      catch (Exception e) {
         e.printStackTrace();
      }
   }
}
