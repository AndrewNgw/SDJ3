package server_application;

import model.Part;

public interface IDAO_Part
{
   void addPart(Part part);
}
