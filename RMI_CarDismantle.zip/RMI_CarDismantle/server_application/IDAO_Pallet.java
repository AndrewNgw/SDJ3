package server_application;

import model.Pallet;

public interface IDAO_Pallet
{
   void addPallet(Pallet pallet);
}
