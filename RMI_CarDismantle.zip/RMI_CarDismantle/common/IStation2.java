package common;

public interface IStation2
{
   // maybe should return a Part but we will just create parts and add in the ArrayList of part in cars
  public void carParts(Car car);
  
  // create a new pallet and add the part on it, store it in the database
  public void loadPallet(Pallet pallet);
  
  // next we will add them in the database
  public void registerParts(Part part);
}
