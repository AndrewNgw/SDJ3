package station2;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import station1.CarDB;

public class PalletDB implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5788413012254835970L;
	private final static String userName = "mrg";
	private final static String password = "mrg";
	private final static String connectString = "jdbc:oracle:thin:@localhost:1521:orcl";
	
	private String sql;
	private Connection connection;
	private PreparedStatement pStatement;
	
	
	public PalletDB()
	{
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		} catch (SQLException e) {
			System.out.println("Could not load drivers");
			e.printStackTrace();
		}
	}

	public void openConnection()
	{
		try {
			connection = DriverManager.getConnection(connectString, userName, password);
			System.out.println("Database connection opened");
			connection.setAutoCommit(false);
		} catch (SQLException e) {
			System.out.println("Error Openning conection");
			e.printStackTrace();
		}
	}
	
	public void closeConnection()
	{
		try {
			connection.close();
			System.out.println("Database connection closed");
		} catch (SQLException e) {
			System.out.println("Error closing connection");
			e.printStackTrace();
		}
	}
	
/*	public void prepareStatementForInsertIntoExtractTable()
	{
		sql = "INSERT INTO EXTRACT_IGC_LOG ( registration_no, flight_date, flight_time," + 
				" latitude, longitude, altitude)" + " VALUES (?, ?, ?, ?, ?, ?)";
		try {
			pStatement = connection.prepareStatement(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}*/

	// have to modify that .. related to our database
	public void Insert( String registration_no, int flight_date, int flight_time,
			double latitude, double longitude, int altitude)
	{
		
		try {
			pStatement.setString(1, registration_no);
			pStatement.setInt(2, flight_date);
			pStatement.setInt(3, flight_time);
			pStatement.setDouble(4, latitude);
			pStatement.setDouble(5, longitude);
			pStatement.setInt(6, altitude);
			
			
			pStatement.executeUpdate();
			
			
//			System.out.println("row added to Database.");
			
			
			
		} catch (SQLException e) {
			if (e.getErrorCode() == 23505) {
				System.out.println("Error: primary key contraint violated");
			} else {
				System.out.println("Error inserting data");
				System.out.println("Error extracting flight log data "+  "\n" 
						+ registration_no + ", " + flight_date + ", " + flight_time + ", "
						+ latitude + ", " + longitude + ", " + altitude);
			}
		} 
	}
	
	public void commit()
	{
		try {
			connection.commit();
		} catch (SQLException e) {
			System.out.println("Error commiting changes");
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		CarDB dbs = new CarDB();
		dbs.openConnection();
	}
}
