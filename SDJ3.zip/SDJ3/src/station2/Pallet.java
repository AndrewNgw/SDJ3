package station2;

import java.io.Serializable;
import java.util.ArrayList;

public class Pallet implements Serializable 
{
   private static final long serialVersionUID = 1665141135554069240L;

   private String palletId;
   private String typeOfPart;
   private String maxWeightCapacity;
   private String productID;
  // private ArrayList<Part> listOfParts;
   
   public Pallet(String palletId,String typeOfPart,String maxWeightCapacity)
   {
      this.palletId = palletId;
      this.typeOfPart = typeOfPart;
      this.maxWeightCapacity = maxWeightCapacity;
      this.productID = "";
  //    listOfParts = new ArrayList<Part>();
   }
   
   public String getTypeOfPart()
   {
      return typeOfPart;
   }
   public void setTypeOfPart(String typeOfPart)
   {
      this.typeOfPart = typeOfPart;
   }
   public void setId(String id)
   {
      this.palletId = id;
   }
   public String getPalletId()
   {
      return palletId;
   }
   public void setMaxWeightCapacity(String maxWeight)
   {
      this.maxWeightCapacity = maxWeight;
   }
   public String getMaxWeightCapacity()
   {
      return maxWeightCapacity;
   }



}
