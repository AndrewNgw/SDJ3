package station2;

import java.io.Serializable;

public class Pallet implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1665141135554069240L;

}
