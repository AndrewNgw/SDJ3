package station2;
import java.io.Serializable;

import station1.Car;


public class Part implements Serializable {

	private static final long serialVersionUID = 7721362195563469935L;

	private String RegisterNumber;
	private String weight;
	private String typeOfPart;
	private String chassisNbr;
	private String PalletID;

	public Part(String registerNbr, String weight, String typeOfPart, String chassisNbr)
	{
		this.RegisterNumber = registerNbr;
		this.weight = weight;
		this.typeOfPart = typeOfPart;
		this.chassisNbr = chassisNbr;
		this.PalletID = "";
	}

	public String getRegisterNumber() {
		return RegisterNumber;
	}

	public void setRegisterNumber(String registerNumber) {
		RegisterNumber = registerNumber;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getTypeOfPart() {
		return typeOfPart;
	}

	public void setTypeOfPart(String typeOfPart) {
		this.typeOfPart = typeOfPart;
	}

	public String getChassisNbr() {
		return chassisNbr;
	}

	public void setChassisNbr(String chassisNbr) {
		this.chassisNbr = chassisNbr;
	}

	public String getPalletID() {
		return PalletID;
	}

	public void setPalletID(String palletID) {
		PalletID = palletID;
	}
	

}
