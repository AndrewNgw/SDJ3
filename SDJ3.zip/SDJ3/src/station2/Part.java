package station2;
import java.io.Serializable;

public class Part implements Serializable {

	private static final long serialVersionUID = 7721362195563469935L;
	
	

}
