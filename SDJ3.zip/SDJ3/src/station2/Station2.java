package station2;

import station1.Car;

public class Station2 implements IStation2 {

	@Override
	public void carParts(Car car) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void registerParts(Part part) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void loadPallet(Pallet pallet) {
		// TODO Auto-generated method stub
		
	}

}
