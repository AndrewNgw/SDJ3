package station3;

public class Station3 implements IStation3 {

	@Override
	public void registerProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

}
