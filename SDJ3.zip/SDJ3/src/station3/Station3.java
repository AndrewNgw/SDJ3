package station3;

import java.rmi.RemoteException;

public class Station3 implements IStation3 {

	private Product product;
	
	// problem with this method because in station 2 we create a Pallet but we let the ProductID blank and we have to find it..
	@Override
	public void registerProduct(String idproduct, String typeofproduct, String typeofpart, String model) throws RemoteException {
		
		product = new Product(idproduct, typeofproduct);
		ProductDB productdb = new ProductDB();
		
		if (typeofproduct == "product")  {
			productdb.start(idproduct, typeofproduct, typeofpart, "");
			productdb.start2(idproduct); }
		else {
			productdb.start(idproduct, typeofproduct, "", model);
			productdb.start2(idproduct);
			}
	}

}