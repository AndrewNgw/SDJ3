package station3;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ProductDB implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3931496973832432906L;
	
	private final static String userName = "mrg2";
	private final static String password = "mrg2";
	private final static String connectString = "jdbc:oracle:thin:@localhost:1521:orcl";
	
	private String sql;
	private Connection connection;
	private PreparedStatement pStatement;
	
	
	public ProductDB()
	{
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		} catch (SQLException e) {
			System.out.println("Could not load drivers");
			e.printStackTrace();
		}
	}

	public void openConnection()
	{
		try {
			connection = DriverManager.getConnection(connectString, userName, password);
			System.out.println("Database connection opened");
			connection.setAutoCommit(false);
		} catch (SQLException e) {
			System.out.println("Error Openning conection");
			e.printStackTrace();
		}
	}
	
	public void closeConnection()
	{
		try {
			connection.close();
			System.out.println("Database connection closed");
		} catch (SQLException e) {
			System.out.println("Error closing connection");
			e.printStackTrace();
		}
	}
	
/*	public void prepareStatementForInsertIntoExtractTable()
	{
		sql = "INSERT INTO EXTRACT_IGC_LOG ( registration_no, flight_date, flight_time," + 
				" latitude, longitude, altitude)" + " VALUES (?, ?, ?, ?, ?, ?)";
		try {
			pStatement = connection.prepareStatement(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}*/

	private void prepareStatementForInsertIntoTable()
	   {
	      sql = "INSERT INTO PRODUCT ( PRODUCTID,TYPEOFPRODUCT, TYPEOFPART, MODEL)"
	                  + " VALUES (?, ?, ?, ?)";
	      try {
	         pStatement = connection.prepareStatement(sql);
	      } catch (SQLException e) {
	         e.printStackTrace();
	      }
	   }
	   
	   private void Insert(String id, String typeOfProduct, String typeofpart, String model)
	   {
	      try {
	         pStatement.setString(1, id);
	         pStatement.setString(2, typeOfProduct);
	         pStatement.setString(3, typeofpart);
	         pStatement.setString(4, model);
	         pStatement.executeUpdate();      
	         
	      } catch (SQLException e) {
	         if (e.getErrorCode() == 23505) {
	            System.out.println("Error: primary key contraint violated");
	         } else {
	            System.out.println("Error inserting data");
	            System.out.println(e);
	         }
	      } 
	   }
	   
	   // problem here ...
	   private void prepareStatementForUpdateTable()
	   {
	      sql = "UPDATE PALLET SET PRODUCTID = ( SELECT IDPRODUCT FROM PRODUCT, PALLET "
	      		+ "WHERE PRODUCT.TYPEOFPART = PALLET.TYPEOFPART )";
	      try {
	         pStatement = connection.prepareStatement(sql);
	      } catch (SQLException e) {
	         e.printStackTrace();
	      }
	   }
	   
	   private void InsertProductID(String id)
	   {
	      try {
	         pStatement.setString(1, id);    
	         
	      } catch (SQLException e) {
	         if (e.getErrorCode() == 23505) {
	            System.out.println("Error: primary key contraint violated");
	         } else {
	            System.out.println("Error inserting data");
	            System.out.println(e);
	         }
	      } 
	   }
	
	/*
	public void Insert( String registration_no, int flight_date, int flight_time,
			double latitude, double longitude, int altitude)
	{
		
		try {
			pStatement.setString(1, registration_no);
			pStatement.setInt(2, flight_date);
			pStatement.setInt(3, flight_time);
			pStatement.setDouble(4, latitude);
			pStatement.setDouble(5, longitude);
			pStatement.setInt(6, altitude);
			
			
			pStatement.executeUpdate();
			
			
//			System.out.println("row added to Database.");
			
			
			
		} catch (SQLException e) {
			if (e.getErrorCode() == 23505) {
				System.out.println("Error: primary key contraint violated");
			} else {
				System.out.println("Error inserting data");
				System.out.println("Error extracting flight log data "+  "\n" 
						+ registration_no + ", " + flight_date + ", " + flight_time + ", "
						+ latitude + ", " + longitude + ", " + altitude);
			}
		} 
	}*/
	
	public void commit()
	{
		try {
			connection.commit();
		} catch (SQLException e) {
			System.out.println("Error commiting changes");
			e.printStackTrace();
		}
	}
	
	public void start(String id, String typeOfProduct, String typeofpart, String model)
	{
		this.openConnection();
		this.prepareStatementForInsertIntoTable();
		this.Insert(id, typeOfProduct, typeofpart, model);
//		System.out.println("Total rows read: " + totalRead);
		this.closeConnection();
	}
	
	public void start2(String Id) {
		this.openConnection();
		this.prepareStatementForUpdateTable();
		this.InsertProductID(Id);
		this.closeConnection();
	}
	
	public static void main(String[] args) {
		ProductDB ProductDB = new ProductDB();
		ProductDB.openConnection();
	}
}
