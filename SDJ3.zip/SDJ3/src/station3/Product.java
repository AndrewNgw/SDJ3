package station3;

import java.io.Serializable;

public class Product implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 4222706038250810657L;
	private String productId;
	private String typeOfProduct;
	private String typeofpart;
	private String model;

	public Product(String productId, String typeOfProduct)
	{
		this.productId = productId;
		this.typeOfProduct = typeOfProduct;
		this.typeofpart = "";
		this.model = "";
	}

	public void setProductId(String Id)
	{
		this.productId = Id;
	}
	public String getproductId()
	{
		return productId;
		
	}
	public void setTypeOfProduct(String tp)
	{
		this.typeOfProduct = tp;
	}
	public String getTypeOfProduct()
	{
		return typeOfProduct;
	}

	public String getTypeofpart() {
		return typeofpart;
	}

	public void setTypeofpart(String typeofpart) {
		this.typeofpart = typeofpart;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}
}
