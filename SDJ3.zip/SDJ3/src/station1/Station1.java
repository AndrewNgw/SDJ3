package station1;
import java.rmi.RemoteException;

public class Station1 implements IStation1 {

	private Car car;
	// this function will allow us to register and weight the car and add it in the database
	@Override
	public void RegisterCarANDWeight(String ChassisNbr, String Model, double CarWeight) throws RemoteException { 
		car = new Car(ChassisNbr, Model, CarWeight);
	//	cardb.start(ChassisNbr, Model, CarWeight);
		// do something between CarDB and the database to store it
		
	}
	
	public void AddCar(Car car) throws RemoteException {
		CarDB cardb = new CarDB();
		cardb.start(car.getChassisNumber(), car.getModel(), car.getCarWeight());
	}

}
