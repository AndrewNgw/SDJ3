﻿namespace WindowsFormsApp2
{
    partial class Dismantlement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTitle = new System.Windows.Forms.Label();
            this.labelChassisNbr = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.labelPart = new System.Windows.Forms.Label();
            this.listBoxParts = new System.Windows.Forms.ListBox();
            this.buttonDismantle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(75, 31);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(162, 20);
            this.labelTitle.TabIndex = 2;
            this.labelTitle.Text = "Car Dismantlement";
            // 
            // labelChassisNbr
            // 
            this.labelChassisNbr.AutoSize = true;
            this.labelChassisNbr.Location = new System.Drawing.Point(48, 95);
            this.labelChassisNbr.Name = "labelChassisNbr";
            this.labelChassisNbr.Size = new System.Drawing.Size(89, 13);
            this.labelChassisNbr.TabIndex = 3;
            this.labelChassisNbr.Text = "Chassis Number :";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(157, 88);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 20);
            this.textBox1.TabIndex = 4;
            // 
            // labelPart
            // 
            this.labelPart.AutoSize = true;
            this.labelPart.Location = new System.Drawing.Point(48, 141);
            this.labelPart.Name = "labelPart";
            this.labelPart.Size = new System.Drawing.Size(80, 13);
            this.labelPart.TabIndex = 5;
            this.labelPart.Text = "Part of the car :";
            // 
            // listBoxParts
            // 
            this.listBoxParts.FormattingEnabled = true;
            this.listBoxParts.Location = new System.Drawing.Point(157, 141);
            this.listBoxParts.Name = "listBoxParts";
            this.listBoxParts.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBoxParts.Size = new System.Drawing.Size(120, 95);
            this.listBoxParts.TabIndex = 7;
            // 
            // buttonDismantle
            // 
            this.buttonDismantle.Location = new System.Drawing.Point(116, 261);
            this.buttonDismantle.Name = "buttonDismantle";
            this.buttonDismantle.Size = new System.Drawing.Size(95, 36);
            this.buttonDismantle.TabIndex = 8;
            this.buttonDismantle.Text = "Dismantle";
            this.buttonDismantle.UseVisualStyleBackColor = true;
            // 
            // Dismantlement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 378);
            this.Controls.Add(this.buttonDismantle);
            this.Controls.Add(this.listBoxParts);
            this.Controls.Add(this.labelPart);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.labelChassisNbr);
            this.Controls.Add(this.labelTitle);
            this.Name = "Dismantlement";
            this.Text = "Dismantlement";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label labelChassisNbr;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label labelPart;
        private System.Windows.Forms.ListBox listBoxParts;
        private System.Windows.Forms.Button buttonDismantle;
    }
}