﻿namespace WindowsFormsApp2
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTitle = new System.Windows.Forms.Label();
            this.buttonCarRegister = new System.Windows.Forms.Button();
            this.buttonDismantleCar = new System.Windows.Forms.Button();
            this.buttonPackaging = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(55, 23);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(207, 20);
            this.labelTitle.TabIndex = 1;
            this.labelTitle.Text = "Auto Dismantling Facility";
            // 
            // buttonCarRegister
            // 
            this.buttonCarRegister.Location = new System.Drawing.Point(59, 81);
            this.buttonCarRegister.Name = "buttonCarRegister";
            this.buttonCarRegister.Size = new System.Drawing.Size(203, 44);
            this.buttonCarRegister.TabIndex = 2;
            this.buttonCarRegister.Text = "Registration";
            this.buttonCarRegister.UseVisualStyleBackColor = true;
            // 
            // buttonDismantleCar
            // 
            this.buttonDismantleCar.Location = new System.Drawing.Point(59, 153);
            this.buttonDismantleCar.Name = "buttonDismantleCar";
            this.buttonDismantleCar.Size = new System.Drawing.Size(203, 44);
            this.buttonDismantleCar.TabIndex = 3;
            this.buttonDismantleCar.Text = "Dismantlement";
            this.buttonDismantleCar.UseVisualStyleBackColor = true;
            // 
            // buttonPackaging
            // 
            this.buttonPackaging.Location = new System.Drawing.Point(59, 221);
            this.buttonPackaging.Name = "buttonPackaging";
            this.buttonPackaging.Size = new System.Drawing.Size(203, 44);
            this.buttonPackaging.TabIndex = 4;
            this.buttonPackaging.Text = "Packaging";
            this.buttonPackaging.UseVisualStyleBackColor = true;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(321, 303);
            this.Controls.Add(this.buttonPackaging);
            this.Controls.Add(this.buttonDismantleCar);
            this.Controls.Add(this.buttonCarRegister);
            this.Controls.Add(this.labelTitle);
            this.Name = "Home";
            this.Text = "Home";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Button buttonCarRegister;
        private System.Windows.Forms.Button buttonDismantleCar;
        private System.Windows.Forms.Button buttonPackaging;
    }
}