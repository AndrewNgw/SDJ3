﻿namespace WindowsFormsApp2
{
    partial class FormCarRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelChassisNbr = new System.Windows.Forms.Label();
            this.labelModel = new System.Windows.Forms.Label();
            this.labelWeight = new System.Windows.Forms.Label();
            this.textBoxChassisNbr = new System.Windows.Forms.TextBox();
            this.textBoxModel = new System.Windows.Forms.TextBox();
            this.textBoxWeight = new System.Windows.Forms.TextBox();
            this.buttonRegister = new System.Windows.Forms.Button();
            this.labelTitle = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelChassisNbr
            // 
            this.labelChassisNbr.AutoSize = true;
            this.labelChassisNbr.Location = new System.Drawing.Point(29, 69);
            this.labelChassisNbr.Name = "labelChassisNbr";
            this.labelChassisNbr.Size = new System.Drawing.Size(89, 13);
            this.labelChassisNbr.TabIndex = 1;
            this.labelChassisNbr.Text = "Chassis Number :";
            // 
            // labelModel
            // 
            this.labelModel.AutoSize = true;
            this.labelModel.Location = new System.Drawing.Point(71, 112);
            this.labelModel.Name = "labelModel";
            this.labelModel.Size = new System.Drawing.Size(42, 13);
            this.labelModel.TabIndex = 2;
            this.labelModel.Text = "Model :";
            // 
            // labelWeight
            // 
            this.labelWeight.AutoSize = true;
            this.labelWeight.Location = new System.Drawing.Point(71, 155);
            this.labelWeight.Name = "labelWeight";
            this.labelWeight.Size = new System.Drawing.Size(47, 13);
            this.labelWeight.TabIndex = 3;
            this.labelWeight.Text = "Weight :";
            // 
            // textBoxChassisNbr
            // 
            this.textBoxChassisNbr.Location = new System.Drawing.Point(136, 62);
            this.textBoxChassisNbr.Name = "textBoxChassisNbr";
            this.textBoxChassisNbr.Size = new System.Drawing.Size(100, 20);
            this.textBoxChassisNbr.TabIndex = 4;
            // 
            // textBoxModel
            // 
            this.textBoxModel.Location = new System.Drawing.Point(136, 105);
            this.textBoxModel.Name = "textBoxModel";
            this.textBoxModel.Size = new System.Drawing.Size(100, 20);
            this.textBoxModel.TabIndex = 5;
            // 
            // textBoxWeight
            // 
            this.textBoxWeight.Location = new System.Drawing.Point(136, 148);
            this.textBoxWeight.Name = "textBoxWeight";
            this.textBoxWeight.Size = new System.Drawing.Size(100, 20);
            this.textBoxWeight.TabIndex = 6;
            // 
            // buttonRegister
            // 
            this.buttonRegister.Location = new System.Drawing.Point(103, 200);
            this.buttonRegister.Name = "buttonRegister";
            this.buttonRegister.Size = new System.Drawing.Size(75, 23);
            this.buttonRegister.TabIndex = 7;
            this.buttonRegister.Text = "Register";
            this.buttonRegister.UseVisualStyleBackColor = true;
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(81, 21);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(110, 20);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "Car Register";
            // 
            // FormCarRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(299, 260);
            this.Controls.Add(this.buttonRegister);
            this.Controls.Add(this.textBoxWeight);
            this.Controls.Add(this.textBoxModel);
            this.Controls.Add(this.textBoxChassisNbr);
            this.Controls.Add(this.labelWeight);
            this.Controls.Add(this.labelModel);
            this.Controls.Add(this.labelChassisNbr);
            this.Controls.Add(this.labelTitle);
            this.Name = "FormCarRegister";
            this.Text = " Car Register";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelChassisNbr;
        private System.Windows.Forms.Label labelModel;
        private System.Windows.Forms.Label labelWeight;
        private System.Windows.Forms.TextBox textBoxChassisNbr;
        private System.Windows.Forms.TextBox textBoxModel;
        private System.Windows.Forms.TextBox textBoxWeight;
        private System.Windows.Forms.Button buttonRegister;
        private System.Windows.Forms.Label labelTitle;
    }
}

