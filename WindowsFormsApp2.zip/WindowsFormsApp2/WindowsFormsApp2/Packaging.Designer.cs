﻿namespace WindowsFormsApp2
{
    partial class Packaging
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTitle = new System.Windows.Forms.Label();
            this.labelPallet = new System.Windows.Forms.Label();
            this.textBoxPalletNumber = new System.Windows.Forms.TextBox();
            this.labelTypeOfProduct = new System.Windows.Forms.Label();
            this.radioButtonPackage = new System.Windows.Forms.RadioButton();
            this.radioButtonSteeringSys = new System.Windows.Forms.RadioButton();
            this.buttonOK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(81, 31);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(213, 20);
            this.labelTitle.TabIndex = 2;
            this.labelTitle.Text = "Packaging for distribution";
            // 
            // labelPallet
            // 
            this.labelPallet.AutoSize = true;
            this.labelPallet.Location = new System.Drawing.Point(37, 79);
            this.labelPallet.Name = "labelPallet";
            this.labelPallet.Size = new System.Drawing.Size(77, 13);
            this.labelPallet.TabIndex = 3;
            this.labelPallet.Text = "Pallet number :";
            // 
            // textBoxPalletNumber
            // 
            this.textBoxPalletNumber.Location = new System.Drawing.Point(133, 72);
            this.textBoxPalletNumber.Name = "textBoxPalletNumber";
            this.textBoxPalletNumber.Size = new System.Drawing.Size(100, 20);
            this.textBoxPalletNumber.TabIndex = 4;
            // 
            // labelTypeOfProduct
            // 
            this.labelTypeOfProduct.AutoSize = true;
            this.labelTypeOfProduct.Location = new System.Drawing.Point(26, 118);
            this.labelTypeOfProduct.Name = "labelTypeOfProduct";
            this.labelTypeOfProduct.Size = new System.Drawing.Size(88, 13);
            this.labelTypeOfProduct.TabIndex = 5;
            this.labelTypeOfProduct.Text = "Type of product :";
            // 
            // radioButtonPackage
            // 
            this.radioButtonPackage.AutoSize = true;
            this.radioButtonPackage.Location = new System.Drawing.Point(133, 114);
            this.radioButtonPackage.Name = "radioButtonPackage";
            this.radioButtonPackage.Size = new System.Drawing.Size(68, 17);
            this.radioButtonPackage.TabIndex = 6;
            this.radioButtonPackage.TabStop = true;
            this.radioButtonPackage.Text = "Package";
            this.radioButtonPackage.UseVisualStyleBackColor = true;
            // 
            // radioButtonSteeringSys
            // 
            this.radioButtonSteeringSys.AutoSize = true;
            this.radioButtonSteeringSys.Location = new System.Drawing.Point(216, 114);
            this.radioButtonSteeringSys.Name = "radioButtonSteeringSys";
            this.radioButtonSteeringSys.Size = new System.Drawing.Size(99, 17);
            this.radioButtonSteeringSys.TabIndex = 7;
            this.radioButtonSteeringSys.TabStop = true;
            this.radioButtonSteeringSys.Text = "Steering system";
            this.radioButtonSteeringSys.UseVisualStyleBackColor = true;
            // 
            // buttonOK
            // 
            this.buttonOK.Location = new System.Drawing.Point(133, 154);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(91, 33);
            this.buttonOK.TabIndex = 8;
            this.buttonOK.Text = "OK";
            this.buttonOK.UseVisualStyleBackColor = true;
            // 
            // Packaging
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 210);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.radioButtonSteeringSys);
            this.Controls.Add(this.radioButtonPackage);
            this.Controls.Add(this.labelTypeOfProduct);
            this.Controls.Add(this.textBoxPalletNumber);
            this.Controls.Add(this.labelPallet);
            this.Controls.Add(this.labelTitle);
            this.Name = "Packaging";
            this.Text = "Packaging";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label labelPallet;
        private System.Windows.Forms.TextBox textBoxPalletNumber;
        private System.Windows.Forms.Label labelTypeOfProduct;
        private System.Windows.Forms.RadioButton radioButtonPackage;
        private System.Windows.Forms.RadioButton radioButtonSteeringSys;
        private System.Windows.Forms.Button buttonOK;
    }
}