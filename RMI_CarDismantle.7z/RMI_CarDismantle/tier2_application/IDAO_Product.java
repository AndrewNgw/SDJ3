package tier2_application;

import model.Product;

public interface IDAO_Product
{
 void addProduct(Product product, String registrationNumber);
}
