package tier2_application;

import model.Car;

public interface IDAO_Car
{
   
   
   void addCar(Car car);

}
