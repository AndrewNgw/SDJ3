package tier2_application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.Car;


public class DAO_Car implements IDAO_Car
{
   private final static String userName = "sdjUser";
   private final static String password = "dwh";
   private final static String connectString = "jdbc:oracle:thin:@localhost:1521:OraBBC18c";
   
   private Connection connection;
   private PreparedStatement pStatement;
   private String sql;
   
   public DAO_Car() {
      try {
         DriverManager.registerDriver(null, null);
      } catch (SQLException e) {
         System.out.println("Could not load drivers");
         e.printStackTrace();
      }
   }
   

   
   private void openConnection()
   {
      try {
         connection = DriverManager.getConnection(connectString, userName, password);
         System.out.println("Database connection opened");
         connection.setAutoCommit(false);
      } catch (SQLException e) {
         System.out.println("Error Openning conection");
         e.printStackTrace();
      }
   }
   
   private void closeConnection()
   {
      try {
         connection.close();
         System.out.println("Database connection closed");
      } catch (SQLException e) {
         System.out.println("Error closing connection");
         e.printStackTrace();
      }
   }
   
   private void prepareStatementForInsertIntoTable()
   {
      sql = "INSERT INTO CAR ( CHASSIS,WEIGHT,MODEL)"
                  + " VALUES (?, ?, ?)";
      try {
         pStatement = connection.prepareStatement(sql);
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }
   
   private void Insert(String chassis,String model,double weight)
   {
      try {
         pStatement.setString(1, chassis);
         pStatement.setString(2, model);
         pStatement.setDouble(3,weight);
         
         
         
         pStatement.executeUpdate();      
         
      } catch (SQLException e) {
         if (e.getErrorCode() == 23505) {
            System.out.println("Error: primary key contraint violated");
         } else {
            System.out.println("Error inserting data");
            System.out.println(e);
         }
      } 
   }
   
   private void commit()
   {
      try {
         connection.commit();
      } catch (SQLException e) {
         System.out.println("Error commiting changes");
         e.printStackTrace();
      }
   }

   @Override
   public void addCar(Car car)
   {
      // TODO Auto-generated method stub
      openConnection();
      prepareStatementForInsertIntoTable();
      
      Insert(car.getChassisNumber(),car.getModel(),car.getCarWeight());
      
      commit();
      closeConnection();
   
   }

}
