package tier2_application;

import model.Pallet;

public interface IDAO_Pallet
{
   void addPart(Pallet pallet);
}
