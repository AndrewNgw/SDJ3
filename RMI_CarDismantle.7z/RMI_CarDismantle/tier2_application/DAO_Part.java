package tier2_application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.Car;
import model.Part;

public class DAO_Part implements IDAO_Part
{
   private final static String userName = "sdjUser";
   private final static String password = "dwh";
   private final static String connectString = "jdbc:oracle:thin:@localhost:1521:OraBBC18c";
   
   private Connection connection;
   private PreparedStatement pStatement;
   private String sql;
   
   public DAO_Part() {
      try {
         DriverManager.registerDriver(null, null);
      } catch (SQLException e) {
         System.out.println("Could not load drivers");
         e.printStackTrace();
      }
   }
   
   @Override
   public void addPart(Part part)
   {
      // TODO Auto-generated method stub
      openConnection();
      prepareStatementForInsertIntoTable();
      
      Insert(part.getPartId(),part.getWeight(),part.getTypeOfPart(),part.getCar().getChassisNumber().toString());
      
      commit();
      closeConnection();
   
   }
   
   private void openConnection()
   {
      try {
         connection = DriverManager.getConnection(connectString, userName, password);
         System.out.println("Database connection opened");
         connection.setAutoCommit(false);
      } catch (SQLException e) {
         System.out.println("Error Openning conection");
         e.printStackTrace();
      }
   }
   
   private void closeConnection()
   {
      try {
         connection.close();
         System.out.println("Database connection closed");
      } catch (SQLException e) {
         System.out.println("Error closing connection");
         e.printStackTrace();
      }
   }
   
   private void prepareStatementForInsertIntoTable()
   {
      sql = "INSERT INTO PART ( ID,WEIGHT,REGISTRATIONNUMBER,TYPEOFPART,CARID)"
                  + " VALUES (?, ?, ?)";
      try {
         pStatement = connection.prepareStatement(sql);
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }
   
   private void Insert(int id,double weight,String registrationNumber,String typeOfPart)
   {
      try {
         pStatement.setInt(1, id);
         pStatement.setDouble(2, weight);
         pStatement.setString(3,registrationNumber);
         pStatement.setString(2, typeOfPart);
        
         
         
         
         pStatement.executeUpdate();      
         
      } catch (SQLException e) {
         if (e.getErrorCode() == 23505) {
            System.out.println("Error: primary key contraint violated");
         } else {
            System.out.println("Error inserting data");
            System.out.println(e);
         }
      } 
   }
   
   private void commit()
   {
      try {
         connection.commit();
      } catch (SQLException e) {
         System.out.println("Error commiting changes");
         e.printStackTrace();
      }
   }



}
