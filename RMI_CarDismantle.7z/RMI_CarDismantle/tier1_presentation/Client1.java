package tier1_presentation;

import java.rmi.Naming;

public class Client1
{
   // This is just a simple test driver. It should be client, normally.
   
   public static void main( String[] args )
   {
      try {
         common.ITier2 tier2 = (common.ITier2) Naming.lookup();
         
         double amount = 853.17;
         
         while( tier2.withdraw( 4711, amount ) )
            System.out.println( "Withdrawn: " + amount );
      } catch( Exception ex ) {
         ex.printStackTrace();
      }
   }
}
