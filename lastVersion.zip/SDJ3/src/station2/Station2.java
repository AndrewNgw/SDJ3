package station2;
import java.rmi.RemoteException;
import java.sql.DriverManager;
import java.sql.Statement;

public class Station2 implements IStation2 {
	
	public void process(String registerNbr, String weight, String typeOfPart, String chassisNbr, 
		String IdPallet, String maxWeightCapacity) throws RemoteException {
		
		// create part & pallet
		Part part;
		Pallet pallet;
		
		part = new Part(registerNbr, weight, typeOfPart, chassisNbr);
		pallet = new Pallet(IdPallet, part.getTypeOfPart(), maxWeightCapacity);
		
		// set the pallet id into the part
		part.setPalletID(IdPallet);
		System.out.println(part.getPalletID());
		
		// add in db
		putpallet(IdPallet, typeOfPart, maxWeightCapacity);
		putpart(registerNbr, weight,typeOfPart,chassisNbr,IdPallet);
	}
	
	private void putpallet(String IdPallet, String typeOfPart, String maxWeightCapacity) {
		String DB_URL = "jdbc:oracle:thin:@localhost:1521:orcl";  
		// Database credentials 
		String USER = "mrg2"; 
		String PASS = "mrg2"; 
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			java.sql.Connection con;
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			Statement stmt = con.createStatement();
			
			stmt.executeUpdate("INSERT INTO PALLET ( IDPALLET,TYPEOFPART,MAXWEIGHTCAPACITY, PRODUCTID )" 
			+ " VALUES ('"+IdPallet+"', '"+typeOfPart+"','"+maxWeightCapacity+"', null)");
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	private void putpart(String registerNbr, String weight, String typeOfPart, String chassisNbr, String palletId) {
		String DB_URL = "jdbc:oracle:thin:@localhost:1521:orcl";  
		// Database credentials 
		String USER = "mrg2"; 
		String PASS = "mrg2"; 
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			java.sql.Connection con;
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			Statement stmt = con.createStatement();
			
			stmt.executeUpdate("INSERT INTO PART ( REGISTERNUMBER, WEIGHT ,TYPEOFPART,CHASSISNBR, PALLETID )" 
			+ " VALUES ('"+registerNbr+"', '"+weight+"', '"+typeOfPart+"','"+chassisNbr+"', '"+palletId+"' )");
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}