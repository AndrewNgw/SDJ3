package station2;
import java.rmi.RemoteException;

public class Station2 implements IStation2 {

	private Part part;
	private Pallet pallet;
	
	// create part and add them in the database
	@Override
	public void registerPart(String registerNbr, String weight, String typeOfPart, String chassisNbr) throws RemoteException{
		// create a part
		part = new Part(registerNbr, weight, typeOfPart, chassisNbr);
		// add in database
		
	}
	@Override
	public void loadPallet(String IdPallet, String typeOfPart, String maxWeightCapacity) throws RemoteException {
		
			// create a pallet
			pallet = new Pallet(IdPallet, part.getTypeOfPart(), maxWeightCapacity);
			part.setPalletID(IdPallet);
			// add a part on it
	}
	
	// add Pallet and Part in the database
	public void addPalletAndPart()  throws RemoteException {
		PalletDB palletdb = new PalletDB();
		palletdb.start(pallet.getPalletId(), pallet.getTypeOfPart(), pallet.getMaxWeightCapacity(), "");
		PartDB partdb = new PartDB();
		partdb.start(part.getRegisterNumber(), part.getWeight(), part.getTypeOfPart(), part.getChassisNbr(), "");
	}
	
}