package station2;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface IStation2 extends Remote {
	
	// next we will add them in the database
	public void registerPart(String registerNbr, String weight, String typeOfPart, String chassisNbr) throws RemoteException;

	public void loadPallet(String IdPallet, String typeOfPart, String maxWeightCapacity) throws RemoteException;
	
	public void addPalletAndPart()  throws RemoteException;
	// create a new pallet and add the part on it, store it in the database
	
}
