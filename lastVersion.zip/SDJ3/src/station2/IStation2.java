package station2;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface IStation2 extends Remote {
	
	
	public void process(String registerNbr, String weight, String typeOfPart, String chassisNbr, 
			String IdPallet, String maxWeightCapacity) throws RemoteException;
	
}
