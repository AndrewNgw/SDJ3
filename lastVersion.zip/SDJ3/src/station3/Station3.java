package station3;

import java.rmi.RemoteException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Station3 implements IStation3 {

	private static final String PACKAGE = "1";
	private static final String Steeringsystem = "2";
 
	
	// problem with this method because in station 2 we create a Pallet but we let the ProductID blank and we have to find it..
	@Override
	public void registerproduct(String idPallet, String typeofproduct) throws RemoteException {
	//	Product product;
		
	//	product = new Product(idproduct, typeofproduct);
	//	ProductDB productdb = new ProductDB();
		
	//	addproduct(idproduct, typeofproduct);
		
		if (typeofproduct.equalsIgnoreCase("package"))
			updatePallet(idPallet,PACKAGE);
		else if (typeofproduct.equalsIgnoreCase("steering system")) {
			updatePallet(idPallet, Steeringsystem);
		}
		
	}
	
	private void addproduct(String idproduct, String typeofproduct) {
		String DB_URL = "jdbc:oracle:thin:@localhost:1521:orcl";  
		// Database credentials 
		String USER = "mrg2"; 
		String PASS = "mrg2"; 
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			java.sql.Connection con;
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			Statement stmt = con.createStatement();
			//ResultSet rs;
			
			stmt.executeUpdate("INSERT INTO PRODUCT (PRODUCTID,TYPEOFPRODUCT)" 
			+ " VALUES ('"+idproduct+"', '"+typeofproduct+"')");
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
		
		private void updatePallet(String idPallet, String idproduct) {
			String DB_URL = "jdbc:oracle:thin:@localhost:1521:orcl";  
			// Database credentials 
			String USER = "mrg2"; 
			String PASS = "mrg2"; 
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
				java.sql.Connection con;
				con = DriverManager.getConnection(DB_URL, USER, PASS);
				Statement stmt = con.createStatement();
				
				stmt.executeUpdate("UPDATE PALLET SET PRODUCTID = '"+idproduct+"' WHERE IDPALLET = '"+idPallet+"'");
			}
			catch (Exception e)
			{
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
	}
}