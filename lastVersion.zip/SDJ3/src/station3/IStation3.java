package station3;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface IStation3 extends Remote {

	void registerproduct(String idPallet, String idproduct) throws RemoteException;
	
}
