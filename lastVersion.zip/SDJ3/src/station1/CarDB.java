package station1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CarDB {

	/**
	 * 
	 */
	private final static String userName = "mrg2";
	private final static String password = "mrg2";
	private final static String connectString = "jdbc:oracle:thin:@localhost:1521:orcl";
	
	private String sql;
	private Connection connection;
	private PreparedStatement pStatement;
	
	
	public CarDB()
	{
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("HelloDB");
		} catch (SQLException e) {
			System.out.println("Could not load drivers");
			e.printStackTrace();
		}
	}

	public void openConnection()
	{
		try {
			connection = DriverManager.getConnection(connectString, userName, password);
			System.out.println("Database connection opened");
			connection.setAutoCommit(false);
		} catch (SQLException e) {
			System.out.println("Error Openning conection");
			e.printStackTrace();
		}
	}
	
	public void closeConnection()
	{
		try {
			connection.close();
			System.out.println("Database connection closed");
		} catch (SQLException e) {
			System.out.println("Error closing connection");
			e.printStackTrace();
		}
	}
	
/*	public void prepareStatementForInsertIntoExtractTable()
	{
		sql = "INSERT INTO EXTRACT_IGC_LOG ( registration_no, flight_date, flight_time," + 
				" latitude, longitude, altitude)" + " VALUES (?, ?, ?, ?, ?, ?)";
		try {
			pStatement = connection.prepareStatement(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}*/

	   private void prepareStatementForInsertIntoTable()
	   {
	      sql = "INSERT INTO CAR (CHASSIS,WEIGHT,MODEL)"
	                  + " VALUES (?, ?, ?)";
	      try {
	         pStatement = connection.prepareStatement(sql);
	      } catch (SQLException e) {
	         e.printStackTrace();
	      }
	   }
	
	
	 private void Insert(String chassis, String weight, String model)
	   {
	      try {
	         pStatement.setString(1, chassis);
	         pStatement.setString(2,weight);
	         pStatement.setString(3,model);
	         
	         pStatement.executeUpdate();   
	         System.out.println("row added to Database.");
	         
	      } catch (SQLException e) {
	         if (e.getErrorCode() == 23505) {
	            System.out.println("Error: primary key contraint violated");
	         } else {
	            System.out.println("Error inserting data");
	            System.out.println(e);
	         }
	      } 
	   }
	

	
	public void commit()
	{
		try {
			connection.commit();
		} catch (SQLException e) {
			System.out.println("Error commiting changes");
			e.printStackTrace();
		}
	}
	
	public void start(String chassis,String weight, String model)
	{
		this.openConnection();
		this.prepareStatementForInsertIntoTable();
		this.Insert(chassis, weight, model);
//		System.out.println("Total rows read: " + totalRead);
		this.closeConnection();
	}
	
	public static void main(String[] args) {
		CarDB CarDB = new CarDB();
		CarDB.openConnection();
	//	CarDB.closeConnection();
	}
}
