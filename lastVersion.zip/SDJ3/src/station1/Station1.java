package station1;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Station1 implements IStation1 {

	// this function will allow us to register and weight the car and add it in the database
	@Override
	public void registercarandweight(String ChassisNbr, String Model, String CarWeight) throws RemoteException { 

		Car car;
		car = new Car(ChassisNbr, Model, CarWeight);
	

		addcar(ChassisNbr, Model, CarWeight);
	}


	public void addcar(String ChassisNbr, String Model, String CarWeight) throws RemoteException {
		String DB_URL = "jdbc:oracle:thin:@localhost:1521:orcl";  
		// Database credentials 
		String USER = "mrg2"; 
		String PASS = "mrg2"; 
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			java.sql.Connection con;
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			Statement stmt = con.createStatement();

			stmt.executeUpdate("INSERT INTO CAR (CHASSIS,MODEL,WEIGHT)" 
					+ " VALUES ('"+ChassisNbr+"', '"+Model+"', '"+CarWeight+"')");
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
