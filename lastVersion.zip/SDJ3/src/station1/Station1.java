package station1;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Station1 implements IStation1 {

	private static final String userName = "mrg2";
	private static final String password = "mrg2";
	private static final String connectString = "jdbc:oracle:thin:@localhost:1521:orcl";

	private String  sql = "INSERT INTO CAR (CHASSIS,WEIGHT,MODEL)"
			+ " VALUES (?, ?, ?)";
	private Connection connection;
	private PreparedStatement pStatement;

	// this function will allow us to register and weight the car and add it in the database
	@Override
	public void registercarandweight(String ChassisNbr, String Model, String CarWeight) throws RemoteException { 
		System.out.println("Hello");

		Car car;

		car = new Car(ChassisNbr, Model, CarWeight);
		System.out.println(car.getChassisNumber() + " " + car.getCarWeight() + " " + car.getModel() );
		
		
		addcar(ChassisNbr, Model, CarWeight);

		//	CarDB cardb = new CarDB();
		//	cardb.start(ChassisNbr, Model, CarWeight);
		//	System.out.println(cardb.toString());

		//	cardb.start(car.getChassisNumber(), car.getModel(), car.getCarWeight());

		/*	public void addcar() throws RemoteException {
	}*/
	}

	
	public void addcar(String ChassisNbr, String Model, String CarWeight) throws RemoteException {
		String DB_URL = "jdbc:oracle:thin:@localhost:1521:orcl";  
		// Database credentials 
		String USER = "mrg2"; 
		String PASS = "mrg2"; 
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			java.sql.Connection con;
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			Statement stmt = con.createStatement();
			ResultSet rs;
			
			stmt.executeUpdate("INSERT INTO CAR (CHASSIS,MODEL,WEIGHT)" 
			+ " VALUES ('"+ChassisNbr+"', '"+Model+"', '"+CarWeight+"')");
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		
		
/*		//	String JDBC_DRIVER = "com.mysql.jdbc.Driver";   
		String DB_URL = "jdbc:oracle:thin:@localhost:1521:orcl";  

		// Database credentials 
		String USER = "mrg2"; 
		String PASS = "mrg2";  

		Connection conn = null; 
		Statement stmt = null;  
		PreparedStatement pStatement;

		//Register JDBC driver 
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   

		//Open a connection
		System.out.println("Connecting to a selected database..."); 
		try {
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		System.out.println("Connected database successfully...");  

		//Execute a query 
		System.out.println("Creating statement..."); 


		String sql = "INSERT INTO CAR (CHASSIS,WEIGHT,MODEL)\"\n" + 
				"	                  + \" VALUES (?, ?, ?)"; 
		try {
			pStatement = connection.prepareStatement(sql);
			pStatement.setString(1, ChassisNbr);
			pStatement.setString(2,CarWeight);
			pStatement.setString(3,Model);
			pStatement.executeUpdate();   
			System.out.println("row added to Database.");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}

}
